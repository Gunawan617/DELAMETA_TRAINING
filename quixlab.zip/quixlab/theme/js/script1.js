$(document).ready(function(){
		

		//real time halaman dashboard.php
				setInterval(function() {
            		$('.load-data1').load('load-data1.php');
          							}, 100);

	
  });


  